import * as React from "react";
interface IWelcomeBannerProps {
    userName: string;
}
declare const WelcomeBanner: React.FC<IWelcomeBannerProps>;
export default WelcomeBanner;
//# sourceMappingURL=WelcomeBanner.d.ts.map