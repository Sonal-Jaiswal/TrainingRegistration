import * as React from "react";
import { SPFI } from "@pnp/sp";
interface IDashboardStatsProps {
    sp: SPFI;
    userEmail: string;
}
declare const DashboardStats: React.FC<IDashboardStatsProps>;
export default DashboardStats;
//# sourceMappingURL=DashboardStats.d.ts.map