
require("./Dashboard.module.css");
const styles = {
  dashboardContainer: 'dashboardContainer_08288625',
  pageTitle: 'pageTitle_08288625',
  pageSubTitle: 'pageSubTitle_08288625',
  headerCard: 'headerCard_08288625',
  userBadge: 'userBadge_08288625',
  sectionCard: 'sectionCard_08288625',
  sectionTitle: 'sectionTitle_08288625',
  quoteCard: 'quoteCard_08288625',
  quoteText: 'quoteText_08288625',
  quoteAuthor: 'quoteAuthor_08288625'
};

export default styles;
