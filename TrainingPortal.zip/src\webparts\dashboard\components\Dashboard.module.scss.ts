
require("./Dashboard.module.css");
const styles = {
  dashboardContainer: 'dashboardContainer_51ec13bd',
  pageTitle: 'pageTitle_51ec13bd',
  quoteCard: 'quoteCard_51ec13bd',
  quoteText: 'quoteText_51ec13bd',
  quoteAuthor: 'quoteAuthor_51ec13bd',
  sectionCard: 'sectionCard_51ec13bd',
  sectionTitle: 'sectionTitle_51ec13bd'
};

export default styles;
