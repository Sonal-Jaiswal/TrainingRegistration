import * as React from "react";

import styles from "./Dashboard.module.scss";

import DashboardStats from "./DashboardStats";
import AvailableTrainings from "./AvailableTrainings";
import MyRegistrations from "./MyRegistrations";

import { IDashboardProps } from "./IDashboardProps";

const Dashboard: React.FC<IDashboardProps> = ({
  sp,
  userName,
  userEmail
}) => {

  return (
    <div className={styles.dashboardContainer}>

      <h1 className={styles.pageTitle}>
        Employee Training Enrollment Portal
      </h1>

      <div className={styles.quoteCard}>

        <div className={styles.quoteText}>
          "Learning never exhausts the mind.
          Every training is a step toward
          excellence."
        </div>

        <div className={styles.quoteAuthor}>
          Continuous Learning @ Capgemini
        </div>

      </div>

      <DashboardStats
        sp={sp}
        userEmail={userEmail}
      />

      <div className={styles.sectionCard}>

        <h2 className={styles.sectionTitle}>
          Available Trainings
        </h2>

        <AvailableTrainings
          sp={sp}
          userName={userName}
          userEmail={userEmail}
        />

      </div>

      <div className={styles.sectionCard}>

        <h2 className={styles.sectionTitle}>
          My Registrations
        </h2>

        <MyRegistrations
          sp={sp}
          userEmail={userEmail}
        />

      </div>

    </div>
  );
};

export default Dashboard;