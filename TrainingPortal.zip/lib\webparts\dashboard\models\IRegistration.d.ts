export interface IRegistration {
    TrainingId: number;
    EmployeeName: string;
    EmployeeEmail: string;
    Status: string;
}
//# sourceMappingURL=IRegistration.d.ts.map