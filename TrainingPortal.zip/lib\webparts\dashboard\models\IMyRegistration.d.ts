export interface IMyRegistration {
    Id: number;
    Title: string;
    EmployeeEmail: string;
    Status: string;
    EnrollmentDate: string;
}
//# sourceMappingURL=IMyRegistration.d.ts.map