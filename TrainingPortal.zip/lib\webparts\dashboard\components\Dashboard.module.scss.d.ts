declare const styles: {
    dashboardContainer: string;
    pageTitle: string;
    pageSubTitle: string;
    headerCard: string;
    userBadge: string;
    sectionCard: string;
    sectionTitle: string;
    quoteCard: string;
    quoteText: string;
    quoteAuthor: string;
};
export default styles;
//# sourceMappingURL=Dashboard.module.scss.d.ts.map