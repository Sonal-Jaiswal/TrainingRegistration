declare const styles: {
    dashboardContainer: string;
    pageTitle: string;
    quoteCard: string;
    quoteText: string;
    quoteAuthor: string;
    sectionCard: string;
    sectionTitle: string;
};
export default styles;
//# sourceMappingURL=Dashboard.module.scss.d.ts.map