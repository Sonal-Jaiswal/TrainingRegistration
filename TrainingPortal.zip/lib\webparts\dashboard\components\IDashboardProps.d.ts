import { SPFI } from "@pnp/sp";
export interface IDashboardProps {
    sp: SPFI;
    userName: string;
    userEmail: string;
}
//# sourceMappingURL=IDashboardProps.d.ts.map