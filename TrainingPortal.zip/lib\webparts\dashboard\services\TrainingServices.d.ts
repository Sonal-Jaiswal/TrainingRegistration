import { SPFI } from "@pnp/sp";
import { IMyRegistration } from "../models/IMyRegistration";
import "@pnp/sp/webs";
import "@pnp/sp/lists";
import "@pnp/sp/items";
import { ITraining } from "../models/ITraining";
export default class TrainingServices {
    private sp;
    private listName;
    constructor(sp: SPFI);
    getAllTrainings(): Promise<ITraining[]>;
    registerTraining(trainingId: number, trainingTitle: string, userName: string, userEmail: string): Promise<void>;
    cancelRegistration(registrationId: number): Promise<void>;
    increaseAvailableSeats(trainingTitle: string): Promise<void>;
    isAlreadyRegistered(trainingId: number, userEmail: string): Promise<boolean>;
    reactivateRegistration(trainingId: number, userEmail: string): Promise<boolean>;
    getMyRegistrations(userEmail: string): Promise<IMyRegistration[]>;
    getRegistrationCount(trainingId: number): Promise<number>;
    updateAvailableSeats(trainingId: number, currentSeats: number): Promise<void>;
}
//# sourceMappingURL=TrainingServices.d.ts.map