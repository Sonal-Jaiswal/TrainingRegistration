import { Version } from "@microsoft/sp-core-library";
import { BaseClientSideWebPart } from "@microsoft/sp-webpart-base";
export interface IDashboardWebPartProps {
}
export default class DashboardWebPart extends BaseClientSideWebPart<IDashboardWebPartProps> {
    private sp;
    protected onInit(): Promise<void>;
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
}
//# sourceMappingURL=DashboardWebPart.d.ts.map