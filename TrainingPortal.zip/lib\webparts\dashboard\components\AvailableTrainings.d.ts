import * as React from "react";
import { SPFI } from "@pnp/sp";
interface IAvailableTrainingsProps {
    sp: SPFI;
    userName: string;
    userEmail: string;
}
declare const AvailableTrainings: React.FC<IAvailableTrainingsProps>;
export default AvailableTrainings;
//# sourceMappingURL=AvailableTrainings.d.ts.map