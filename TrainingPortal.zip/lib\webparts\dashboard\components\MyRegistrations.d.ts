import * as React from "react";
import { SPFI } from "@pnp/sp";
interface IMyRegistrationsProps {
    sp: SPFI;
    userEmail: string;
}
declare const MyRegistrations: React.FC<IMyRegistrationsProps>;
export default MyRegistrations;
//# sourceMappingURL=MyRegistrations.d.ts.map