import * as React from "react";
import { IDashboardProps } from "./IDashboardProps";
declare const Dashboard: React.FC<IDashboardProps>;
export default Dashboard;
//# sourceMappingURL=Dashboard.d.ts.map